/** @format */

const { start } = require('./app');
start();
